 export const proxy = 'https://cors-anywhere.herokuapp.com/';
export const key = 'f7208de8821d6f68bdc0d647ab21c12f';

//'f7208de8821d6f68bdc0d647ab21c12f';

//'097cbed89e8777e53338a6104d52dc2a';

